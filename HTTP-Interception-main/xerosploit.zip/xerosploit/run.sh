#!/bin/sh
python /opt/xerosploit/xerosploit.py


